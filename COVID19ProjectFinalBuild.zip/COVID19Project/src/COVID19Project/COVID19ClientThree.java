package COVID19Project;

import java.net.*;
import java.io.*;
import java.awt.*;
import java.util.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;

 
public class COVID19ClientThree extends JFrame {
    int num;
    String str;
    ResultSet rs;
    Vector records;
    GridBagLayout gb1;
    GridBagConstraints gbc;
    JScrollPane sp;
    JTextArea result;
    JLabel label;
    incidence inc;
    int i=0;
    ObjectInputStream br = null;
    Socket clientSocket = null;

    
    public COVID19ClientThree()
    {
        label = new JLabel("Covid Details");
        result = new JTextArea(120,220);
        str = "";
        inc = null;
        records = new Vector();
        gb1 = new GridBagLayout();
        gbc = new GridBagConstraints();
        getContentPane().setLayout(gb1);
        gbc.gridx = 0;
        gbc.gridy = 0;
        getContentPane().add(label,gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        sp = new JScrollPane(result);
        getContentPane().add(sp,gbc);
        
        
        
   
            try {
                Scanner scanner = new Scanner(System.in);
                  clientSocket = new Socket("localhost",8000);
                  DataOutputStream osToServer
                    = new DataOutputStream(clientSocket.getOutputStream());
                  int num = 3;
                  osToServer.writeInt(num);
                  osToServer.flush();
                  
                  DataOutputStream osToServerint
                    = new DataOutputStream(clientSocket.getOutputStream());
                 
                  int number;
          do {
                System.out.println("Please enter an integer number:");
                while (! scanner .hasNextInt()) {
                System.out.println("That's not a integer Please Enter integer again!");
                 scanner .next(); 
                        }
                 number = scanner.nextInt();
                } while (number <= 0);
                osToServerint.writeInt(number);
                osToServerint.flush();
                   
              DataOutputStream osToServerstring
                    = new DataOutputStream(clientSocket.getOutputStream());

                String countrycode;
                System.out.println("Please enter a Contry code:");
                while (!scanner.hasNext("[A-Za-z]*")) {
                System.out.println("That's not a Valid Counrty Code Enter Again!");
                 scanner.next(); 
                        }
                 countrycode = scanner.next();
                osToServerstring.writeUTF(countrycode);
                osToServerstring.flush();
                  
                  br = new ObjectInputStream(clientSocket.getInputStream());
                  records =(Vector)br.readObject();
                  br.close();
                  result.setText("");
                  int i =0;
                  
                  result.append("ref_num\tCountry_name\tCountry_code\tDate\tConfirmed_cases_num\tConfirmed_deaths_num\tConfirmed_recoveries_num\tConfirmed_cases_incr\tConfirmed_deaths_incr\tConfirmed_recoveries_incr\tDays_since_first\tDays_since_100\tConfirmed_PopPct\tDeaths_PopPct\t\tRecoveries_PopPct");
                  result.append("\n----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");

                  while(i < records.size())
                  {
                      inc = (incidence)records.elementAt(i);
                      num = inc.getRef_num();
                      result.append(num + "\t");
                      str = inc.getCountry_name();
                      result.append(str + "\t");
                      str = inc.getCountry_code();
                      result.append(str + "\t");
                      str = inc.getDate();
                      result.append(str + "\t");
                      num = inc.getConfirmed_cases_num();
                      result.append(num + "\t" + "\t");	
                      num = inc.getConfirmed_deaths_num();
                      result.append(num + "\t" + "\t");
                      num = inc.getConfirmed_recoveries_num();
                      result.append(num + "\t" + "\t");
                      num = inc.getConfirmed_cases_incr();
                      result.append(num + "\t" + "\t");
                      num = inc.getConfirmed_deaths_incr();
                      result.append(num + "\t" + "\t");
                      num = inc.getConfirmed_recoveries_incr();
                      result.append(num + "\t" + "\t");
                      num = inc.getDays_since_first();
                      result.append(num + "\t" + "\t");
                      num = inc.getDays_since_100();
                      result.append(num + "\t" + "\t");
                      num = inc.getConfirmed_PopPct();
                      result.append(num + "\t" + "\t");
                      num = inc.getDeaths_PopPct();
                      result.append(num + "\t" + "\t");
                      num = inc.getRecoveries_PopPct();
                      result.append(num  + "\n");
                      i++;    
                  }
                  records.removeAllElements();
   
            } catch (IOException | ClassNotFoundException ex) {
                Logger.getLogger(COVID19ClientTwo.class.getName()).log(Level.SEVERE, null, ex);
            }
          
    }

}
