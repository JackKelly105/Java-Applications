package COVID19Project;


import java.util.*;
import javax.swing.*;

 
public class COVID19Main extends JFrame{
 
    public static void main(String[ ] args)
     {
         
         Scanner scan = new Scanner(System.in);
         
         while (true) {
             System.out.println("\n::Welcome to COVID-19 Menu::");
             // Display the menu
             System.out.println("1\t Search records with Country Code and Date");
             System.out.println("2\t Search records with Country Code, Start Date and End Date");
             System.out.println("3\t Search records with Country Code with integer value X for most recent records");
             System.out.println("4\t Search records by reference number (Records range from 1 to 69907)");
             System.out.println("5\t Search records with Country Name and Date");
             System.out.println("6\t Search records with Country Name, Start Date and End Date");
             System.out.println("7\t Search records with Country Name with integer value X for most recent records");
             System.out.println("9\t Exit");
             
             System.out.println("\nPlease enter your choice:");
             
             //Get user's choice
             int choice = scan.nextInt();//accept user input
             
             
             switch (choice) {
                 case 1:
                     COVID19ClientOne server1=new COVID19ClientOne(); 
                     server1.setSize(2000, 1800);
                     server1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     server1.pack();
                     server1.setVisible(true);
                     break;
                 case 2:
                     COVID19ClientTwo server2 = new COVID19ClientTwo();
                     server2.setSize(2000, 1800);
                     server2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     server2.pack();
                     server2.setVisible(true);
                     break;
                 case 3:
                     COVID19ClientThree server3=new COVID19ClientThree();
                     server3.setSize(2000, 1800);
                     server3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     server3.pack();
                     server3.setVisible(true);
                     break;
                case 4:
                     COVID19ClientFour server4=new COVID19ClientFour();
                     server4.setSize(2000, 1800);
                     server4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     server4.pack();
                     server4.setVisible(true);
                     break;
                case 5:
                     COVID19ClientFive server5=new COVID19ClientFive();
                     server5.setSize(2000, 1800);
                     server5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     server5.pack();
                     server5.setVisible(true);
                     break;
                case 6:
                     COVID19ClientSix server6=new COVID19ClientSix();
                     server6.setSize(2000, 1800);
                     server6.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     server6.pack();
                     server6.setVisible(true);
                     break;
                case 7:
                     COVID19ClientSeven server7=new COVID19ClientSeven();
                     server7.setSize(2000, 1800);
                     server7.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                     server7.pack();
                     server7.setVisible(true);
                     break;
                 case 9: System.out.println("Goodbye");
                 System.exit(0);
                 default: System.out.println("Incorrect input!!! Please re-enter choice from our menu");
             }
             
         }
                   
      }

}
