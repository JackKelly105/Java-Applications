package COVID19Project;

import java.io.*;
import static java.lang.System.out;
import java.sql.*;
import java.net.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

 

public class COVID19Server{
  
    
 public static void main(String[] args) {
    System.out.println("Server started....awaiting connections");
    try  {
      // Create a server socket
      ServerSocket serverSocket = new ServerSocket(8000);

      int clientNo = 1; // The number of a client

      while (true)   {
        // Listen for a new connection request
        Socket connectToClient = serverSocket.accept();

        // Print the new connect number on the console
        System.out.println("Start thread for client " + clientNo);

        // Find the client's host name, and IP address
        InetAddress clientInetAddress = connectToClient.getInetAddress();
        System.out.println("Client " + clientNo + "'s host name is " + clientInetAddress.getHostName());
        System.out.println("Client " + clientNo + "'s IP Address is "+ clientInetAddress.getHostAddress());

        // Create a new thread for the connection
        HandleAClient thread = new HandleAClient(connectToClient);
        
        thread.start();// Start the new thread
        clientNo++;// Increment clientNo
      }
    }
    catch(IOException ex)  {
      System.err.println(ex);
    }
  }

}
    
class HandleAClient extends Thread {
    Statement stmt=null;
    Vector records = new Vector(10,10);
    ResultSet rs = null;
    Connection con = null;
    ObjectOutputStream out =null;
    String str = null;
    incidence inc = null;
   

  private Socket connectToClient; // A connected socket

  /**Construct a thread*/
  public HandleAClient(Socket socket)  {
    connectToClient = socket;
  }
  @Override
  public void run(){

      DataInputStream input = null;
      try {
          input = new DataInputStream(
                  connectToClient.getInputStream());
          int caseNum;
          caseNum = input.readInt();
          System.out.println("Number received from client: " + caseNum);
          switch (caseNum) {
              case 1:
                  CounrtyCodeAndDate();
                  break;
              case 2:
                  CounrtyCodeAndDateStartEnd();
                  break;
              case 3:
                  CounrtyCodeAndIntValue();
                  break;
              case 4:
                  ReferenceNumber();
                  break;
              case 5:
                  CounrtyNameAndDate();
                  break;
              case 6:
                  CounrtyNameAndDateStartEnd();
                  break;
              case 7:
                  CounrtyNameAndIntValue();
                  break;
              default: System.out.println("Incorrect input!!! Please re-enter choice from our menu");
          }
      } catch (IOException ex) {
          Logger.getLogger(HandleAClient.class.getName()).log(Level.SEVERE, null, ex);
      } finally {
          try {
              input.close();
          } catch (IOException ex) {
              Logger.getLogger(HandleAClient.class.getName()).log(Level.SEVERE, null, ex);
          }
      }
   
}
    
  public void  CounrtyCodeAndDate(){
         while(true)
        {
                try {
                
                     DataInputStream isFromClientdate = new DataInputStream(
                    connectToClient.getInputStream());

                String date = isFromClientdate.readUTF();

               System.out.println("Date received from client: " + date);
               
                DataInputStream isFromClient = new DataInputStream(
                    connectToClient.getInputStream());

                String countrycode = isFromClient.readUTF();

               System.out.println("Country Code received from client: " + countrycode);
                    
               int CC;
                    out = new ObjectOutputStream(connectToClient.getOutputStream());
                    System.out.println("OutputStream received");
                    
                    try {
                 
                     
                     Class.forName("com.mysql.jdbc.Driver");
                        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/covid19_by_country?zeroDateTimeBehavior=convertToNull", "root", "");
                        
                        stmt = con.createStatement();
                        rs = stmt.executeQuery("SELECT * FROM incidence WHERE date LIKE '%" + date + "%' AND country_code LIKE '%" + countrycode + "%' LIMIT 1");
                        records.removeAllElements();
                        
                        ResultSetMetaData RSMD = rs.getMetaData();
                        CC = RSMD.getColumnCount();
                        
                        while(rs.next())
                        {
                            inc = new incidence();
                            inc.setRef_num(rs.getInt(1));
                            inc.setCountry_name(rs.getString(2));
                            inc.setCountry_code(rs.getString(3));
                            inc.setDate(rs.getString(4));
                            inc.setConfirmed_cases_num(rs.getInt(5));
                            inc.setConfirmed_deaths_num(rs.getInt(6));
                            inc.setConfirmed_recoveries_num(rs.getInt(7));
                            inc.setConfirmed_cases_incr(rs.getInt(8));
                            inc.setConfirmed_deaths_incr(rs.getInt(9));
                            inc.setConfirmed_recoveries_incr(rs.getInt(10));
                            inc.setDays_since_first(rs.getInt(11));
                            inc.setDays_since_100(rs.getInt(12));
                            inc.setConfirmed_PopPct (rs.getInt(13));
                            inc.setDeaths_PopPct  (rs.getInt(14));
                            inc.setRecoveries_PopPct(rs.getInt(15));
                            records.addElement(inc);
                            System.out.println("row returned");
                        }
                        
                        out.writeObject(records);
                        out.close();
                        System.out.println("Rows returned");
         
                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                } catch (IOException ex) {
                    Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
    
    }
   public void  CounrtyCodeAndDateStartEnd(){
         while(true)
        {
                try {
                    
                    DataInputStream isFromClientdate = new DataInputStream(
                    connectToClient.getInputStream());

                String date = isFromClientdate.readUTF();

               System.out.println("First Date received from client: " + date);
               
                DataInputStream isFromClientdatetwo = new DataInputStream(
                    connectToClient.getInputStream());

                String datetwo = isFromClientdatetwo.readUTF();

               System.out.println("Second Date received from client: " + datetwo);
               
               DataInputStream isFromClient = new DataInputStream(
                    connectToClient.getInputStream());

                String countrycode = isFromClient.readUTF();

               System.out.println("Country Code received from client: " + countrycode);
               
                    int CC;
                   
                    out = new ObjectOutputStream(connectToClient.getOutputStream());
                    System.out.println("OutputStream received");
                    
                    try {
                 
                     
                     Class.forName("com.mysql.jdbc.Driver");
                        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/covid19_by_country?zeroDateTimeBehavior=convertToNull", "root", "");
                        stmt = con.createStatement();
                        rs = stmt.executeQuery("SELECT * FROM incidence WHERE country_code LIKE '%" + countrycode + "%' AND date BETWEEN '"+ date + "%' AND '"+ datetwo + "%'");
                        records.removeAllElements();
                        
                        ResultSetMetaData RSMD = rs.getMetaData();
                        CC = RSMD.getColumnCount();
                        
                        while(rs.next())
                        {
                            inc = new incidence();
                            inc.setRef_num(rs.getInt(1));
                            inc.setCountry_name(rs.getString(2));
                            inc.setCountry_code(rs.getString(3));
                            inc.setDate(rs.getString(4));
                            inc.setConfirmed_cases_num(rs.getInt(5));
                            inc.setConfirmed_deaths_num(rs.getInt(6));
                            inc.setConfirmed_recoveries_num(rs.getInt(7));
                            inc.setConfirmed_cases_incr(rs.getInt(8));
                            inc.setConfirmed_deaths_incr(rs.getInt(9));
                            inc.setConfirmed_recoveries_incr(rs.getInt(10));
                            inc.setDays_since_first(rs.getInt(11));
                            inc.setDays_since_100(rs.getInt(12));
                            inc.setConfirmed_PopPct (rs.getInt(13));
                            inc.setDeaths_PopPct  (rs.getInt(14));
                            inc.setRecoveries_PopPct(rs.getInt(15));
                            records.addElement(inc);
                            System.out.println("row returned");
                        }
                        
                        out.writeObject(records);
                        out.close();
                        System.out.println("Rows returned");
         
                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                } catch (IOException ex) {
                    Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
    
    }
    public void  CounrtyCodeAndIntValue(){
         while(true)
        {
                try {
                    
                     DataInputStream isFromClientnum = new DataInputStream(
                    connectToClient.getInputStream());

                int num = isFromClientnum.readInt();

               System.out.println("integer received from client: " + num);
               
                DataInputStream isFromClient = new DataInputStream(
                    connectToClient.getInputStream());

                String countrycode = isFromClient.readUTF();

               System.out.println("Country Code received from client: " + countrycode);
                    
               int CC;
                   
                    out = new ObjectOutputStream(connectToClient.getOutputStream());
                    System.out.println("OutputStream received");
                    
                    try {
                 
                     
                     Class.forName("com.mysql.jdbc.Driver");
                        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/covid19_by_country?zeroDateTimeBehavior=convertToNull", "root", "");
                        stmt = con.createStatement();
                        rs = stmt.executeQuery("SELECT * FROM incidence WHERE country_code LIKE '%" + countrycode + "%' ORDER BY date DESC LIMIT " + num + "");
                        records.removeAllElements();
                        
                        ResultSetMetaData RSMD = rs.getMetaData();
                        CC = RSMD.getColumnCount();
                        
                        while(rs.next())
                        {
                            inc = new incidence();
                            inc.setRef_num(rs.getInt(1));
                            inc.setCountry_name(rs.getString(2));
                            inc.setCountry_code(rs.getString(3));
                            inc.setDate(rs.getString(4));
                            inc.setConfirmed_cases_num(rs.getInt(5));
                            inc.setConfirmed_deaths_num(rs.getInt(6));
                            inc.setConfirmed_recoveries_num(rs.getInt(7));
                            inc.setConfirmed_cases_incr(rs.getInt(8));
                            inc.setConfirmed_deaths_incr(rs.getInt(9));
                            inc.setConfirmed_recoveries_incr(rs.getInt(10));
                            inc.setDays_since_first(rs.getInt(11));
                            inc.setDays_since_100(rs.getInt(12));
                            inc.setConfirmed_PopPct (rs.getInt(13));
                            inc.setDeaths_PopPct  (rs.getInt(14));
                            inc.setRecoveries_PopPct(rs.getInt(15));
                            records.addElement(inc);
                            System.out.println("row returned");
                        }
                        
                        out.writeObject(records);
                        out.close();
                        System.out.println("Rows returned");
         
                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                } catch (IOException ex) {
                    Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
    
    }
    
     public void  ReferenceNumber(){
         while(true)
        {
                try {
                    
                     DataInputStream isFromClientnum = new DataInputStream(
                    connectToClient.getInputStream());

                int num = isFromClientnum.readInt();

               System.out.println("Reference Number received from client: " + num);

               int CC;
                   
                    out = new ObjectOutputStream(connectToClient.getOutputStream());
                    System.out.println("OutputStream received");
                    
                    try {
                 
                     
                     Class.forName("com.mysql.jdbc.Driver");
                        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/covid19_by_country?zeroDateTimeBehavior=convertToNull", "root", "");
                        stmt = con.createStatement();
                        rs = stmt.executeQuery("SELECT * FROM incidence WHERE ref_num = " + num + "");
                        records.removeAllElements();
                        
                        ResultSetMetaData RSMD = rs.getMetaData();
                        CC = RSMD.getColumnCount();
                        
                        while(rs.next())
                        {
                            inc = new incidence();
                            inc.setRef_num(rs.getInt(1));
                            inc.setCountry_name(rs.getString(2));
                            inc.setCountry_code(rs.getString(3));
                            inc.setDate(rs.getString(4));
                            inc.setConfirmed_cases_num(rs.getInt(5));
                            inc.setConfirmed_deaths_num(rs.getInt(6));
                            inc.setConfirmed_recoveries_num(rs.getInt(7));
                            inc.setConfirmed_cases_incr(rs.getInt(8));
                            inc.setConfirmed_deaths_incr(rs.getInt(9));
                            inc.setConfirmed_recoveries_incr(rs.getInt(10));
                            inc.setDays_since_first(rs.getInt(11));
                            inc.setDays_since_100(rs.getInt(12));
                            inc.setConfirmed_PopPct (rs.getInt(13));
                            inc.setDeaths_PopPct  (rs.getInt(14));
                            inc.setRecoveries_PopPct(rs.getInt(15));
                            records.addElement(inc);
                            System.out.println("row returned");
                        }
                        
                        out.writeObject(records);
                        out.close();
                        System.out.println("Rows returned");
         
                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                } catch (IOException ex) {
                    Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
    
    }
     
     public void  CounrtyNameAndDate(){
         while(true)
        {
                try {
                
                     DataInputStream isFromClientdate = new DataInputStream(
                    connectToClient.getInputStream());

                String date = isFromClientdate.readUTF();

               System.out.println("Date received from client: " + date);
               
                DataInputStream isFromClient = new DataInputStream(
                    connectToClient.getInputStream());

                String countryname = isFromClient.readUTF();

               System.out.println("Country Name received from client: " + countryname);
                    
               int CC;
                    out = new ObjectOutputStream(connectToClient.getOutputStream());
                    System.out.println("OutputStream received");
                    
                    try {
                 
                     
                     Class.forName("com.mysql.jdbc.Driver");
                        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/covid19_by_country?zeroDateTimeBehavior=convertToNull", "root", "");
                        
                        stmt = con.createStatement();
                        rs = stmt.executeQuery("SELECT * FROM incidence WHERE date LIKE '%" + date + "%' AND country_name = '" + countryname + "' LIMIT 1");
                        records.removeAllElements();
                        
                        ResultSetMetaData RSMD = rs.getMetaData();
                        CC = RSMD.getColumnCount();
                        
                        while(rs.next())
                        {
                            inc = new incidence();
                            inc.setRef_num(rs.getInt(1));
                            inc.setCountry_name(rs.getString(2));
                            inc.setCountry_code(rs.getString(3));
                            inc.setDate(rs.getString(4));
                            inc.setConfirmed_cases_num(rs.getInt(5));
                            inc.setConfirmed_deaths_num(rs.getInt(6));
                            inc.setConfirmed_recoveries_num(rs.getInt(7));
                            inc.setConfirmed_cases_incr(rs.getInt(8));
                            inc.setConfirmed_deaths_incr(rs.getInt(9));
                            inc.setConfirmed_recoveries_incr(rs.getInt(10));
                            inc.setDays_since_first(rs.getInt(11));
                            inc.setDays_since_100(rs.getInt(12));
                            inc.setConfirmed_PopPct (rs.getInt(13));
                            inc.setDeaths_PopPct  (rs.getInt(14));
                            inc.setRecoveries_PopPct(rs.getInt(15));
                            records.addElement(inc);
                            System.out.println("row returned");
                        }
                        
                        out.writeObject(records);
                        out.close();
                        System.out.println("Rows returned");
         
                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                } catch (IOException ex) {
                    Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
    
    }
     
     public void  CounrtyNameAndDateStartEnd(){
         while(true)
        {
                try {
                    
                    DataInputStream isFromClientdate = new DataInputStream(
                    connectToClient.getInputStream());

                String date = isFromClientdate.readUTF();

               System.out.println("First Date received from client: " + date);
               
                DataInputStream isFromClientdatetwo = new DataInputStream(
                    connectToClient.getInputStream());

                String datetwo = isFromClientdatetwo.readUTF();

               System.out.println("Second Date received from client: " + datetwo);
               
               DataInputStream isFromClient = new DataInputStream(
                    connectToClient.getInputStream());

                String countryname = isFromClient.readUTF();

               System.out.println("Country Name received from client: " + countryname);
               
                    int CC;
                   
                    out = new ObjectOutputStream(connectToClient.getOutputStream());
                    System.out.println("OutputStream received");
                    
                    try {
                 
                     
                     Class.forName("com.mysql.jdbc.Driver");
                        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/covid19_by_country?zeroDateTimeBehavior=convertToNull", "root", "");
                        stmt = con.createStatement();
                        rs = stmt.executeQuery("SELECT * FROM incidence WHERE country_name = '" + countryname + "' AND date BETWEEN '"+ date + "%' AND '"+ datetwo + "%'");
                        records.removeAllElements();
                        
                        ResultSetMetaData RSMD = rs.getMetaData();
                        CC = RSMD.getColumnCount();
                        
                        while(rs.next())
                        {
                            inc = new incidence();
                            inc.setRef_num(rs.getInt(1));
                            inc.setCountry_name(rs.getString(2));
                            inc.setCountry_code(rs.getString(3));
                            inc.setDate(rs.getString(4));
                            inc.setConfirmed_cases_num(rs.getInt(5));
                            inc.setConfirmed_deaths_num(rs.getInt(6));
                            inc.setConfirmed_recoveries_num(rs.getInt(7));
                            inc.setConfirmed_cases_incr(rs.getInt(8));
                            inc.setConfirmed_deaths_incr(rs.getInt(9));
                            inc.setConfirmed_recoveries_incr(rs.getInt(10));
                            inc.setDays_since_first(rs.getInt(11));
                            inc.setDays_since_100(rs.getInt(12));
                            inc.setConfirmed_PopPct (rs.getInt(13));
                            inc.setDeaths_PopPct  (rs.getInt(14));
                            inc.setRecoveries_PopPct(rs.getInt(15));
                            records.addElement(inc);
                            System.out.println("row returned");
                        }
                        
                        out.writeObject(records);
                        out.close();
                        System.out.println("Rows returned");
         
                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                } catch (IOException ex) {
                    Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
    
    }
         public void  CounrtyNameAndIntValue(){
         while(true)
        {
                try {
                    
                     DataInputStream isFromClientnum = new DataInputStream(
                    connectToClient.getInputStream());

                int num = isFromClientnum.readInt();

               System.out.println("integer received from client: " + num);
               
                DataInputStream isFromClient = new DataInputStream(
                    connectToClient.getInputStream());

                String countryname = isFromClient.readUTF();

               System.out.println("Country Name received from client: " + countryname);
                    
               int CC;
                   
                    out = new ObjectOutputStream(connectToClient.getOutputStream());
                    System.out.println("OutputStream received");
                    
                    try {
                 
                     
                     Class.forName("com.mysql.jdbc.Driver");
                        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/covid19_by_country?zeroDateTimeBehavior=convertToNull", "root", "");
                        stmt = con.createStatement();
                        rs = stmt.executeQuery("SELECT * FROM incidence WHERE country_name = '" + countryname + "' ORDER BY date DESC LIMIT " + num + "");
                        records.removeAllElements();
                        
                        ResultSetMetaData RSMD = rs.getMetaData();
                        CC = RSMD.getColumnCount();
                        
                        while(rs.next())
                        {
                            inc = new incidence();
                            inc.setRef_num(rs.getInt(1));
                            inc.setCountry_name(rs.getString(2));
                            inc.setCountry_code(rs.getString(3));
                            inc.setDate(rs.getString(4));
                            inc.setConfirmed_cases_num(rs.getInt(5));
                            inc.setConfirmed_deaths_num(rs.getInt(6));
                            inc.setConfirmed_recoveries_num(rs.getInt(7));
                            inc.setConfirmed_cases_incr(rs.getInt(8));
                            inc.setConfirmed_deaths_incr(rs.getInt(9));
                            inc.setConfirmed_recoveries_incr(rs.getInt(10));
                            inc.setDays_since_first(rs.getInt(11));
                            inc.setDays_since_100(rs.getInt(12));
                            inc.setConfirmed_PopPct (rs.getInt(13));
                            inc.setDeaths_PopPct  (rs.getInt(14));
                            inc.setRecoveries_PopPct(rs.getInt(15));
                            records.addElement(inc);
                            System.out.println("row returned");
                        }
                        
                        out.writeObject(records);
                        out.close();
                        System.out.println("Rows returned");
         
                    } catch (ClassNotFoundException | SQLException ex) {
                        Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                } catch (IOException ex) {
                    Logger.getLogger(COVID19Server.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
    
    }
}      
