/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package COVID19Project;

import java.io.Serializable;

/**
 *
 * @author jack
 */
public class incidence implements Serializable{
    
    private int ref_num;
    private String country_name;
    private String country_code;
    private String date;
    private int confirmed_cases_num;
    private int confirmed_deaths_num;
    private int confirmed_recoveries_num;
    private int confirmed_cases_incr;
    private int confirmed_deaths_incr;
    private int confirmed_recoveries_incr;
    private int days_since_first;
    private int days_since_100;
    private int confirmed_PopPct;
    private int deaths_PopPct;
    private int recoveries_PopPct;

    public incidence() {
    }

    public incidence(int ref_num, String country_name, String country_code, String date, int confirmed_cases_num, int confirmed_deaths_num, int confirmed_recoveries_num, int confirmed_cases_incr, int confirmed_deaths_incr, int confirmed_recoveries_incr, int days_since_first, int days_since_100, int confirmed_PopPct, int deaths_PopPct, int recoveries_PopPct) {
        this.ref_num = ref_num;
        this.country_name = country_name;
        this.country_code = country_code;
        this.date = date;
        this.confirmed_cases_num = confirmed_cases_num;
        this.confirmed_deaths_num = confirmed_deaths_num;
        this.confirmed_recoveries_num = confirmed_recoveries_num;
        this.confirmed_cases_incr = confirmed_cases_incr;
        this.confirmed_deaths_incr = confirmed_deaths_incr;
        this.confirmed_recoveries_incr = confirmed_recoveries_incr;
        this.days_since_first = days_since_first;
        this.days_since_100 = days_since_100;
        this.confirmed_PopPct = confirmed_PopPct;
        this.deaths_PopPct = deaths_PopPct;
        this.recoveries_PopPct = recoveries_PopPct;
    }

    
    /**
     * @return the ref_num
     */
    public int getRef_num() {
        return ref_num;
    }

    /**
     * @param ref_num the ref_num to set
     */
    public void setRef_num(int ref_num) {
        this.ref_num = ref_num;
    }

    /**
     * @return the country_name
     */
    public String getCountry_name() {
        return country_name;
    }

    /**
     * @param country_name the country_name to set
     */
    public void setCountry_name(String country_name) {
        this.country_name = country_name;
    }

    /**
     * @return the country_code
     */
    public String getCountry_code() {
        return country_code;
    }

    /**
     * @param country_code the country_code to set
     */
    public void setCountry_code(String country_code) {
        this.country_code = country_code;
    }

    /**
     * @return the date
     */
    public String getDate() {
        return date;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the confirmed_cases_num
     */
    public int getConfirmed_cases_num() {
        return confirmed_cases_num;
    }

    /**
     * @param confirmed_cases_num the confirmed_cases_num to set
     */
    public void setConfirmed_cases_num(int confirmed_cases_num) {
        this.confirmed_cases_num = confirmed_cases_num;
    }

    /**
     * @return the confirmed_deaths_num
     */
    public int getConfirmed_deaths_num() {
        return confirmed_deaths_num;
    }

    /**
     * @param confirmed_deaths_num the confirmed_deaths_num to set
     */
    public void setConfirmed_deaths_num(int confirmed_deaths_num) {
        this.confirmed_deaths_num = confirmed_deaths_num;
    }

    /**
     * @return the confirmed_recoveries_num
     */
    public int getConfirmed_recoveries_num() {
        return confirmed_recoveries_num;
    }

    /**
     * @param confirmed_recoveries_num the confirmed_recoveries_num to set
     */
    public void setConfirmed_recoveries_num(int confirmed_recoveries_num) {
        this.confirmed_recoveries_num = confirmed_recoveries_num;
    }

    /**
     * @return the confirmed_cases_incr
     */
    public int getConfirmed_cases_incr() {
        return confirmed_cases_incr;
    }

    /**
     * @param confirmed_cases_incr the confirmed_cases_incr to set
     */
    public void setConfirmed_cases_incr(int confirmed_cases_incr) {
        this.confirmed_cases_incr = confirmed_cases_incr;
    }

    /**
     * @return the confirmed_deaths_incr
     */
    public int getConfirmed_deaths_incr() {
        return confirmed_deaths_incr;
    }

    /**
     * @param confirmed_deaths_incr the confirmed_deaths_incr to set
     */
    public void setConfirmed_deaths_incr(int confirmed_deaths_incr) {
        this.confirmed_deaths_incr = confirmed_deaths_incr;
    }

    /**
     * @return the confirmed_recoveries_incr
     */
    public int getConfirmed_recoveries_incr() {
        return confirmed_recoveries_incr;
    }

    /**
     * @param confirmed_recoveries_incr the confirmed_recoveries_incr to set
     */
    public void setConfirmed_recoveries_incr(int confirmed_recoveries_incr) {
        this.confirmed_recoveries_incr = confirmed_recoveries_incr;
    }

    /**
     * @return the days_since_first
     */
    public int getDays_since_first() {
        return days_since_first;
    }

    /**
     * @param days_since_first the days_since_first to set
     */
    public void setDays_since_first(int days_since_first) {
        this.days_since_first = days_since_first;
    }

    /**
     * @return the days_since_100
     */
    public int getDays_since_100() {
        return days_since_100;
    }

    /**
     * @param days_since_100 the days_since_100 to set
     */
    public void setDays_since_100(int days_since_100) {
        this.days_since_100 = days_since_100;
    }

    /**
     * @return the confirmed_PopPct
     */
    public int getConfirmed_PopPct() {
        return confirmed_PopPct;
    }

    /**
     * @param confirmed_PopPct the confirmed_PopPct to set
     */
    public void setConfirmed_PopPct(int confirmed_PopPct) {
        this.confirmed_PopPct = confirmed_PopPct;
    }

    /**
     * @return the deaths_PopPct
     */
    public int getDeaths_PopPct() {
        return deaths_PopPct;
    }

    /**
     * @param deaths_PopPct the deaths_PopPct to set
     */
    public void setDeaths_PopPct(int deaths_PopPct) {
        this.deaths_PopPct = deaths_PopPct;
    }

    /**
     * @return the recoveries_PopPct
     */
    public int getRecoveries_PopPct() {
        return recoveries_PopPct;
    }

    /**
     * @param recoveries_PopPct the recoveries_PopPct to set
     */
    public void setRecoveries_PopPct(int recoveries_PopPct) {
        this.recoveries_PopPct = recoveries_PopPct;
    }

}
